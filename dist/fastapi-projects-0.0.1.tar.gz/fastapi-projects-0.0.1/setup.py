from setuptools import Extension, setup

setup()
